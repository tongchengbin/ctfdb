#!/usr/bin/env bash
echo $1 > /flag
# rm -rf /start.sh
