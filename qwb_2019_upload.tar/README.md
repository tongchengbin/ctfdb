# 强网杯 2019 Upload

## 题目详情

- **2019 强网杯 第一题，Web ThinkPHP 5 应用**

## 考点

- 代码审计
- Unserialize

## 启动

    docker-compose up -d
    open http://127.0.0.1:8302/

## 版权

该题目复现环境尚未取得主办方及出题人相关授权，如果侵权，请联系本人删除（ i@zhaoj.in ）
